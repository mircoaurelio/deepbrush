Deepbrush — parkour

Original text-only AI-generated photograph.
photo.png: source photo fitted for the editor. depth.png: imagegen relative inverse depth, white near and black far. normal.png: derived view-space normals. combined.png: RG octahedral normal, B depth, A coverage. All maps match the fitted photo dimensions.

Depth is an AI-generated interpretation, not calibrated geometry; fine alignment and accuracy are approximate. Normals and combined data are derived from this depth and verified byte for byte. depth-imagegen-original.png preserves the generated source. See provenance.json for hashes, dimensions and prompt.
