Mapshroom Deep Brush — statue

photo.png: generated photo. depth.png: relative inverse depth (white near). normal.png: view-space normal RGB. combined.png: RG octahedral normal, B depth, A coverage. All 1280 x 853.
Depth source: Depth Anything V2 Small. Normals and combined are derived from the supplied depth and verified together. See provenance.json.
