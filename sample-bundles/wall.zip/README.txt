# Generated photo and matched maps

Created with the built-in image generator. These are independent AI-generated studies inspired by the subjects and surface types in Adobe Project Deep Brush, not Adobe event assets.

All images are 1280 x 853. photo.png is the source photo; depth.png is relative inverse depth (white = near); normal.png is the Mapshroom view-space normal visualization; combined.png stores octahedral normals in RG, relative depth in B and coverage in A. The same combined map is loaded by the brush editor.

Depth Anything V2 Small (CPU q8, pinned revision) estimates depth from the generated photo. Mapshroom derives normals from that depth. These are matched estimated maps, not ground-truth metric geometry. See provenance.json for model revision, dimensions, methods and SHA-256 hashes.
