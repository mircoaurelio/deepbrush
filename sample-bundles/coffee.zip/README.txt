Deepbrush — coffee

CC0 photo by Rachel Michetti / Pikolo Espresso Bar. https://scikit-image.org/docs/0.25.x/api/skimage.data.html#skimage.data.coffee
photo.png: source photo fitted for the editor. depth.png: imagegen relative inverse depth, white near and black far. normal.png: derived view-space normals. combined.png: RG octahedral normal, B depth, A coverage. All maps match the fitted photo dimensions.

Depth is an AI-generated interpretation, not calibrated geometry; fine alignment and accuracy are approximate. Normals and combined data are derived from this depth and verified byte for byte. depth-imagegen-original.png preserves the generated source. See provenance.json for hashes, dimensions and prompt.
